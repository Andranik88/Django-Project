from django.contrib import admin
from .models import *


admin.site.register(Home)
admin.site.register(BackGround)
admin.site.register(Menu)
admin.site.register(OurMenu)
admin.site.register(About)
admin.site.register(Contact)
admin.site.register(Sendit)