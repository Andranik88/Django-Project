from typing import Any
from django.http import HttpRequest, HttpResponse
from django.shortcuts import render
from django.views import generic
from .models import *
from .forms import SenditForm
# Create your views here.



class HomeListView(generic.ListView):
    template_name = 'base.html'


    def get(self, request):
        # context = self._extract_all_data()


    # @staticmethod
    # def _extract_all_data():
        intros = Home.objects.all()
        back = BackGround.objects.get()
        menu = Menu.objects.all()
        menus = OurMenu.objects.all()
        info = About.objects.get()
        contact = Contact.objects.all()

        context = {
            'intros': intros,
            'back':back,
            'menu': menu,
            'menus': menus,
            'info': info,
            'contact': contact,
        }
        return render(request, self.template_name,context)
    # return context

    def post(self, request):
        form = SenditForm(request.POST)
        if form.is_valid():
            form.save()
        else:
            form = SenditForm()

        return render(request, self.template_name,{'form':form})    



