from django.db import models
from phonenumber_field.modelfields import PhoneNumberField


# Create your models here.


class Home(models.Model): 
    name = models.CharField('Name', max_length=255)
    description = models.CharField('Description', max_length=255)
    txt = models.TextField('Text')


    def __str__(self) -> str:
        return self.name
    

    class Meta:
        verbose_name = 'Home'
        verbose_name_plural = 'Home'



class BackGround(models.Model):
    img1 = models.ImageField('Image1', upload_to='media')
    img2 = models.ImageField('Image2', upload_to='media')
    img3 = models.ImageField('Image3', upload_to='media')
    img4 = models.ImageField('Image4', upload_to='media')


    def __str__(self) -> str:
        return "Home Background"
    
    class Meta:
        verbose_name = 'Home Background'
        verbose_name_plural = 'Home Background'


class Menu(models.Model):
    name = models.CharField('Name', max_length=255)
    size1 = models.CharField('Size1', max_length=20)
    size2 = models.CharField('Size2', max_length=20)
    price1 = models.DecimalField('Price1', decimal_places=2, max_digits=4)
    price2 = models.DecimalField('Price2', decimal_places=2, max_digits=4)
    img = models.ImageField('Image', upload_to="media")


    def __str__(self) -> str:
        return self.name
    
    class Meta:
        verbose_name = 'Menu'
        verbose_name_plural = 'Menu'


class OurMenu(models.Model):
    name = models.CharField('Name', max_length=255)
    size1 = models.CharField('Size1', max_length=20)
    size2 = models.CharField('Size2', max_length=20)
    price1 = models.DecimalField('Price1', decimal_places=2, max_digits=4)
    price2 = models.DecimalField('Price2', decimal_places=2, max_digits=4)
    img = models.ImageField('Image', upload_to="media")


    def __str__(self) -> str:
        return self.name
    
    class Meta:
        verbose_name = 'OurMenu'
        verbose_name_plural = 'OurMenu'





class About(models.Model):
    title = models.TextField('Title')
    txt1 = models.TextField('Text1')
    txt2 = models.TextField('Text2')
    txt3 = models.TextField('Text3', null=True)


    def __str__(self) -> str:
        return self.title
    

    class Meta:
        verbose_name = 'About'
        verbose_name_plural = 'About'



class Contact(models.Model):
    title = models.CharField('Title', max_length=255)
    txt = models.TextField('Text')
    email = models.EmailField('Email')
    phone = PhoneNumberField('Phone Number')


    def __str__(self) -> str:
        return self.title
    

    class Meta:
        verbose_name = 'Contact'
        verbose_name_plural = 'Contact'



class Sendit(models.Model):
    name = models.CharField('Name', max_length=255)
    email = models.EmailField('Email')
    message = models.TextField('Message...')


    def __str__(self) -> str:
        return self.name
    

    class Meta:
        verbose_name = 'Sendit'
        verbose_name_plural = 'Sendit'