from django.forms import ModelForm
from .models import Sendit


class SenditForm(ModelForm):
    class Meta:
        model = Sendit
        fields = ('name', 'email', 'message')